#!/bin/bash
python3 Assignment.py -t "/home/student/test"
