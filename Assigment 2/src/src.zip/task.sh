#!/bin/bash
./Assignment.py -t "/home/student/test"